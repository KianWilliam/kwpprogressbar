Package progressbar version 1.0.0 is designed for those sites in which the owner would like to show up with a load bar 
on loading a page with her/his choice.
To do so, first after checking if the two plugins (approximateloadtime and progressbar) are enabled, you have to load each website
page to obtain a relative time load of that page so that it will be saved in the database.
(We ignore the internet speed of your clients in this version, in the next version their internet speed shall be considered too).
THE PLUGIN WORKS ONLY BASED ON YOUR SERVER LOAD TIME .
After that, put your approximate time on no checking option or disable the plugin to keep the performance.
No go to progress bar plugin and select the loadbar you would rather
Also input the pages you would not like to be decorated with a loadbar,remember this option works ONLY with 
seo rewrite url set to yes from global configuration of your joomla backend, 
e.g  sitemap.html | blog.html  
Also if you would not like the main page of your site shows up with loadbard you have to input the url without http, https, www
and it works ONLY with browsers that does not show http(s) and www in address bar(like Chrome)
In the next version it will work with all sort of broswers.
I have got the original idea from helix template designers , so we have to thank them 
In case of any problem contact us at:
webarchitect@kwproductions121.ir
Long live science
